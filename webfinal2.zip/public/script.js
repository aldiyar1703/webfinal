document.getElementById('get-started').addEventListener('click', () => {
    alert('Redirecting to registration page...');
    window.location.href = '/register';
});
